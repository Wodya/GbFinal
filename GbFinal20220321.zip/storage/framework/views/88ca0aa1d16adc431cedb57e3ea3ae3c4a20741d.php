<?php $__env->startSection('Поиск','| Шаг 2  '); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-lg ms-30 me-30 mt-30 bg-main" >
        <search-step2-component :offers = '<?php echo json_encode($offers, 15, 512) ?>' :user = '<?php echo json_encode($user, 15, 512) ?>' :product = '<?php echo json_encode($product, 15, 512) ?>' back="<?php echo e(url()->previous()); ?>"
                                change-quantity-url="<?php echo e(route("changeQuantity",["offerId"=>"offerId", "quantity"=>"quantity"])); ?>" >
        </search-step2-component>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/search_step2.blade.php ENDPATH**/ ?>