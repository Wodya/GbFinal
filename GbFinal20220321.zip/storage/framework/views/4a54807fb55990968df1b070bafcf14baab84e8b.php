<?php $__env->startSection('Поиск','| Шаг 1  '); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-lg ms-30 me-30 bg-main" >
        <p class="fs-1 mb-30 mt-30">Выберите бренд</p>
        <div class="row back-color-neutral h-48 fs-18 fw-bold rounded-3 border border-1">
            <div class="col d-flex justify-content-center align-items-center">
                Бренд
            </div>
            <div class="col d-flex justify-content-center align-items-center">
                Артикул
            </div>
            <div class="col-6 d-flex justify-content-start align-items-center">
                Наименование
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a class="row bg-white h-48 fs-16 fw-normal rounded-3 border border-1" href="<?php echo e(route('searchStep2',['productId' => $product->id])); ?>">
                <div class="col d-flex justify-content-center align-items-center">
                    <?php echo e($product->brand->name); ?>

                </div>
                <div class="col d-flex justify-content-center align-items-center">
                    <?php echo e($product->code); ?>

                </div>
                <div class="col-6 d-flex justify-content-lg-start align-items-center">
                    <?php echo e($product->name); ?>

                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="fs-2 mb-30 mt-30">Поиск не дал результатов</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/search_step1.blade.php ENDPATH**/ ?>