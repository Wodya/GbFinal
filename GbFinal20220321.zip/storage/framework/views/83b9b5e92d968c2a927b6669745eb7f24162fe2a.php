<?php $__env->startSection('title','| Codermen.com '); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center align-items-center flex-fill">
        <div class="d-flex justify-content-center align-items-center main-cards flex-column ">
            <div class="d-flex justify-content-between">
                <div class="main-card">
                    <p class="ms-3 mt-3 fs-5">Купить запчасти</p>

                </div>
                <div class="main-card">
                    <p class="ms-3 mt-3 fs-5">Запись на ремонт</p>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <div class="main-card">
                    <p class="ms-3 mt-3 fs-5 w-50">Найти ближайшую автомойку</p>
                </div>
                <div class="main-card">
                    <p class="ms-3 mt-3 fs-5">Найти шиномонтаж</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/index.blade.php ENDPATH**/ ?>