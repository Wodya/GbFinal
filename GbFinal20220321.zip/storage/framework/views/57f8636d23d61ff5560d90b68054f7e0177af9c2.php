<!doctype html>
<html <?php echo app('translator')->get('en'); ?>>
<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</head>

<body>
<div id="app">
    
    <header-component user="<?php echo e(Auth::user()->name); ?>" search-url="<?php echo e(route("searchStep1","find")); ?>"></header-component>
    <div class="d-flex justify-content-between">
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex-fill p-2 bg-main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
<?php echo $__env->yieldContent('script'); ?>
></div>
</body>
</html>
<script>
    import HeaderComponent from "../../js/components/HeaderComponent";
    export default {
        components: {HeaderComponent}
    }
</script>
<?php /**PATH /var/www/html/resources/views/layouts/main.blade.php ENDPATH**/ ?>