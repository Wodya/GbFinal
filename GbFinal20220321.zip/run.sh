alias sail='bash vendor/bin/sail'
APP_PORT=3001 ./vendor/bin/sail up -d