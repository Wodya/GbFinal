<template>
    <div>Hello World.</div>
</template>

<script>
export default {
    mounted() {
        console.log("Example component mounted");
    }
};
</script>
